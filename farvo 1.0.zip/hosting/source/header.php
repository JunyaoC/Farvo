<nav class="navbar navbar-light navbar-expand-md" style="background-color: #FFD25A;padding: 0.5rem;width: 100%; position: sticky;top: 0;z-index: 10;">
    <div class="container-fluid">
        <div class="row" style="width: 100%;margin: 0;">
            <div class="col-8">
                <a class="navbar-brand text-left d-lg-flex" href="#" style="font-family: Cabin, sans-serif;font-weight: bold;margin: 0;padding: 0 0 0 1rem;width: 100%;font-size: 19px;align-items: center; color: #32322C;">FARVO</a>
            </div>
            <div class="col-4 d-flex justify-content-end">
                <a href="#" class="btn userManualButton" style="font-family: Cabin, sans-serif;font-weight: bold; background-color: #FFD25A; color:#32322C;" type="submit">User Manual</a>
                <div class="d-lg-flex justify-content-lg-end" style="flex-direction: column;">
                    <form method="POST" action="/assets/php/userLogoutProc.php" style="width: 100%;padding: 0;display: flex;justify-content: center;">
                        <button class="btn" style="font-family: Cabin, sans-serif;font-weight: bold; background-color: #FFD25A; color:#32322C;" type="submit" id="userLogout">Sign Out</button>       
                                  
                    </form>
                </div>   
            </div>
                
        </div>
    </div>
</nav>
