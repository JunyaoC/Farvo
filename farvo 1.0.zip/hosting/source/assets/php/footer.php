<style>
.footer {

   left: 0;
   bottom: 0;
   width: 100%;;
   color: black;
   text-align: center;
   font-family:Cabin, sans-serif;
   padding: 1rem 0 1rem 0;
   background: #E6E6E3;
}
</style>


<div class="footer">
	<img src="assets/img/logo.png" style="max-width:60px"class="img-responsive">
<p>Developed by team Zettabyte from Bachelor Of Computer Science ( Data Engineering ) 2U2I study mode</p>


</div>
